

// standard
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>
//define getcwd
#include <unistd.h> 
// ncurses (linux)
#include <ncurses.h>
// time 
#include <time.h>


#include "libc-key.c" 
#include "libc-ide-graphics.c" 
 

char cwd[PATH_MAX];
int posy, posx, mycursor ; 
int scrollcurx = 0 ; 

void strtofile( char *str  )
{  
      FILE *fpout;
      char txtout[40];
      fpout = fopen( "file.c" , "wb+");
      fclose( fpout );
      int return_strcount = 0;
      char ptr[strlen(str)+1];
      int i,j = 0;
      fpout = fopen( "file.c" , "ab+");
      //for(i=0;   str[i]!='\0'; i++)
      for(i=0;  i<= 400 ; i++)
      {
         snprintf( txtout  , 10 , "%c", str[i] );
         fputs(    txtout  , fpout );
      } 
      fclose( fpout );
}








void loadfile(  char *filein ){
  int fetchi;
  FILE *fp5;
  FILE *fp6;
  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];
  int posread = 0;

  int i ; 
  for(i=0; i <= PATH_MAX-1; i++)
    cwd[ i ] = ' ';

  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
          strncpy( fetchline, "" , PATH_MAX );
          fgets(fetchlinetmp, PATH_MAX, fp6); 

          if ( !feof(fp6) ) 
           for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            //if ( fetchlinetmp[ fetchi ] != '\n' )
            if ( fetchlinetmp[ fetchi ] != '\0' )
	    {
              //fetchline[fetchi]= fetchlinetmp[fetchi];
	      cwd[ posread++ ] = fetchlinetmp[ fetchi ];
	      mycursor = posread ; 
	    }

     }
     fclose( fp6 );
     mycursor = 0 ; 
   }
}





 







int ch;
int mycolor = 2 ; 
int mycolorreverse = 0 ; 
int main() { nstartncurses_color_2(  );


    int ch , i ; 
    int rows, cols;  
    getmaxyx( stdscr, rows, cols);
    char charo[PATH_MAX];
    char foochar[PATH_MAX];

 

    int thegameover = 0;
    strncpy( cwd , "  " , PATH_MAX );

    loadfile( "file.c" );
    mycursor = 0; 

    while( thegameover == 0 ) 
    {	
                if ( mycolorreverse <= 0 ) mycolorreverse = 0 ; 
                if ( mycolor <= 0 ) mycolor = 0 ; 
                if ( mycursor <= 0 ) mycursor = 0 ; 
                if ( scrollcurx <= 0 ) scrollcurx = 0 ; 

                attron( A_REVERSE ); color_set( COLOR_BLUE, NULL ); 
                attron( A_REVERSE ); color_set( COLOR_BLACK, NULL ); 
                attron( A_REVERSE ); color_set( COLOR_BLACK, NULL ); 
                attron( A_REVERSE ); color_set( COLOR_BLACK, NULL ); 
                attroff( A_REVERSE ); color_set( COLOR_BLACK, NULL ); 
                attron( A_REVERSE ); color_set( COLOR_BLUE, NULL ); 


                color_set( mycolor, NULL );
                if ( mycolorreverse ==1 ) attron( A_REVERSE ); else attroff( A_REVERSE ); 
                ncerase();
		posy = 2; posx = 1; 

                for(i= scrollcurx ; cwd[i]!='\0'; i++)
                {
		    attroff( A_REVERSE );
                    color_set( mycolor, NULL );
		    if ( mycursor == i  ) attron( A_REVERSE );
		    mvaddch( posy, posx, cwd[i] );
		    if ( cwd[ i ] == '\n' ) 
		    { mvaddch(posy,posx,' '); posy++; posx = 0; }
		    posx++;
                } 
                
		attron( A_REVERSE );
		 
		attron( A_REVERSE );
		color_set( 0, NULL);
                for(i=0; i <= cols-1; i++)
		  mvaddch( rows-1, i , ' ');

		mvprintw( rows-1, 0, "|F5:COMPILE/RUN|" );
                ncdisplaytime( rows-1, cols-6 );

                ncmenubar(  0 );

		attroff( A_REVERSE );
	        ch = getch();
                switch( ch )
		{


      default:
      case 10:
             if ( ch == 10 ) ch = '\n';
             strncpy( foochar ,  "" , PATH_MAX);
             strncpy( foochar ,  string_cut( cwd , 1 , mycursor ) , PATH_MAX);
             i = snprintf( charo , 3 , "%c", ch );
             strncat( foochar , charo , PATH_MAX - strlen(  foochar ) - 1);
             strncat( foochar , string_cut( cwd , mycursor+1  , strlen( cwd ) ) , PATH_MAX - strlen( foochar ) - 1);
             strncpy( cwd ,  foochar , PATH_MAX);
             mycursor++;
         break;


      case KEY_BACKSPACE:
         strncpy( foochar ,  "" , PATH_MAX);
         strncpy( foochar ,  string_cut( cwd , 1 , mycursor -1 ) , PATH_MAX);
         strncat( foochar , string_cut( cwd , mycursor+1  , strlen( cwd ) ) , PATH_MAX - strlen( foochar ) - 1);
         strncpy( cwd , foochar , PATH_MAX);
         mycursor--;
         break; 

                 	case 27:
                         mycolor = 0;
			 break;

                 	case KEY_GFUNCF5:
			 attroff( A_REVERSE );
			 color_set( 0, NULL );
			 ncerase();
                         strtofile( cwd );
			 ncruncmd( " gcc  -lm -o file  file.c   ;   ./file  ; ncpresskey  " );
			 break;

                    case KEY_GFUNCF1:
                         loadfile( "file.c" );
			 break;

                     case KEY_GCTRLG:
                         mycursor = 1;
                         scrollcurx = 0;
			 break;

                     case KEY_GFUNCF2:
                         strtofile( cwd );
			 break;


                 	case KEY_GRIGHT:
                         mycursor++;
			 break;


            case KEY_GPAGEUP:
            posy = strcharseekback( cwd , '\n' , mycursor-1 );
	    mycursor = posy-1;
            scrollcurx = mycursor;
            posy = strcharseekback( cwd , '\n' , mycursor-1 );
	    mycursor = posy-1;
            scrollcurx = mycursor;
            posy = strcharseekback( cwd , '\n' , mycursor-1 );
	    mycursor = posy-1;
            scrollcurx = mycursor;
	    break;

                   case KEY_GPAGEDOWN:
                    i = strcharseek( cwd , '\n' , mycursor );
                    mycursor = ++i;
                    scrollcurx = mycursor;
                    i = strcharseek( cwd , '\n' , mycursor );
                    mycursor = ++i;
                    scrollcurx = mycursor;
                    i = strcharseek( cwd , '\n' , mycursor );
                    mycursor = ++i;
                    scrollcurx = mycursor;
		    break;

              case KEY_GCTRLL:
                color_set( mycolor, NULL );
                attroff( A_REVERSE ); 
                getmaxyx( stdscr, rows, cols);
                ncerase();
                ncerase();
		break;


            case KEY_GUP:
            posy = strcharseekback( cwd , '\n' , mycursor-1 );
	    mycursor = posy-1;
	    break;

                   case KEY_GDOWN:
                    i = strcharseek( cwd , '\n' , mycursor );
                    mycursor = ++i;
		    break;

                 	case KEY_GLEFT:
                         mycursor--;
			 break;


                 	case KEY_GFUNCF11:
                         scrollcurx--;
			 break;
                 	case KEY_GFUNCF12:
                         scrollcurx++;
			 break;


		}
	}
	endwin();
	return 0;
}


